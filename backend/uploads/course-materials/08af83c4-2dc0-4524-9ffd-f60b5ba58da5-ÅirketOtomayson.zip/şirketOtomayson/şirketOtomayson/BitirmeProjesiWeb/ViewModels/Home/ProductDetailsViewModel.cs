﻿using BitirmeProjesiWeb.Models;

namespace BitirmeProjesiWeb.ViewModels.Home
{
    public class ProductDetailsViewModel : BaseViewModel
    {
        public Product Product { get; set; }
    }
}