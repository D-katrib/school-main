﻿using BitirmeProjesiWeb.Models;

namespace BitirmeProjesiWeb.ViewModels.Home
{
    public class PostDetailsViewModel : BaseViewModel
    {
        public Post Post { get; set; }
    }
}