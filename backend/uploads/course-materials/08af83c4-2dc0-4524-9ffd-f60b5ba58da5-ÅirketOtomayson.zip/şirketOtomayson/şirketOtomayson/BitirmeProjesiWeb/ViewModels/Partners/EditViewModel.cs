﻿namespace BitirmeProjesiWeb.ViewModels.Partners
{
    public class EditViewModel : CreateViewModel
    {
        public int Id { get; set; }
        public string ExistingLogoPath { get; set; }
    }
}