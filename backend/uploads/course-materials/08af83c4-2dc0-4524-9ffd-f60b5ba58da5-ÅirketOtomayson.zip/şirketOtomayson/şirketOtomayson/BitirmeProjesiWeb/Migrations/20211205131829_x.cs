﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BitirmeProjesiWeb.Migrations
{
    public partial class x : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
